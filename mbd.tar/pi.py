#!/data/data/io.neoterm/files/usr/bin/env python3

MCHS_PKG_NAME="mchs"
MCHS_PKG_ARCH="aarch64"
MCHS_PKG_MAINTAINER="@MCHS"
MCHS_PKG_VERSION="1.0"
MCHS_PKG_HOMEPAGE="https://tuberboy.com"
MCHS_PKG_DEPENDS="php"
MCHS_PKG_SIZE="111"
MCHS_PKG_DESCRIPTION="Main Repo"