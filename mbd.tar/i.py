#!/data/data/io.neoterm/files/usr/bin/env python3

MCHS_PKG_NAME="mchs"
MCHS_PKG_ARCH="aarch64"
MCHS_PKG_MAINTAINER="@MCHS"
MCHS_PKG_VERSION="1.0"
MCHS_PKG_HOMEPAGE="https://tuberboy.com/MCHS"
MCHS_PKG_DEPENDS="python"
MCHS_PKG_SIZE="11"
MCHS_PKG_DESCRIPTION="Just for personal use now"

